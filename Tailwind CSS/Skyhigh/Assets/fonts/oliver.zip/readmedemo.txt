This demo font is free for PERSONAL USE, but any donation are very appreciated

Here is the link to purchase commercial license:
https://creativemarket.com/Pentagonistudio/10215363-Olivera-Chic-Modern-Serif

For Corporate use you have to purchase Corporate license

You can purchase here too :
https://filosofont.com/

If you need a custom license please contact us at
pentagonistudio@gmail.com

Paypal donation : https://paypal.me/pentagonistudio

Visit our store for more great fonts :
https://filosofont.com/

Thank you!

